import React from 'react';
import './App.css';
import Github_users from './components/github_users';

function App() {
  return (
<Github_users />
  );
}

export default App;
